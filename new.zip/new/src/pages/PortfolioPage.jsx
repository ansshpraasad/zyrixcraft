import React from 'react';
import { motion } from 'framer-motion';

const PortfolioPage = () => {
  const projects = [
    {
      title: 'E-commerce Platform',
      category: 'Web Development',
      description: 'A modern e-commerce platform built with React and Node.js',
      image: '',
      status: 'completed'
    },
    {
      title: 'Mobile Banking App',
      category: 'Mobile App',
      description: 'Secure and user-friendly mobile banking application',
      image: '',
      status: 'completed'
    },
    {
      title: 'Portfolio Website',
      category: 'Web Design',
      description: 'Creative portfolio website for a digital agency',
      image: '',
      status: 'completed'
    },
    {
      title: 'Task Management Tool',
      category: 'Web Development',
      description: 'Collaborative task management application',
      image: '',
      status: 'completed'
    },
    {
      title: 'Restaurant Booking System',
      category: 'Web Application',
      description: 'Online reservation system for restaurants',
      image: '',
      status: 'completed'
    },
    {
      title: 'Fitness Tracking App',
      category: 'Mobile App',
      description: 'Mobile app for tracking workouts and nutrition',
      image: '',
      status: 'coming-soon'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white pt-24">
      <div className="container mx-auto px-6">
        {/* Hero Section */}
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Portfolio</h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Explore our latest projects and see how we've helped businesses grow
          </p>
        </motion.div>

        {/* Projects Grid */}
        <motion.div
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {projects.map((project, index) => (
            <motion.div
              key={index}
              className="group relative"
              variants={itemVariants}
            >
              <div className="bg-white/5 backdrop-blur-lg rounded-xl overflow-hidden">
                <div className="aspect-video bg-gradient-to-br from-pink-500/10 to-violet-500/10 flex items-center justify-center">
                  <span className="text-6xl group-hover:scale-110 transition-transform duration-300">
                    {project.image}
                  </span>
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm px-3 py-1 rounded-full bg-white/10 text-gray-300">
                      {project.category}
                    </span>
                    {project.status === 'coming-soon' && (
                      <span className="text-sm px-3 py-1 rounded-full bg-pink-500/20 text-pink-400">
                        Coming Soon
                      </span>
                    )}
                  </div>
                  <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                  <p className="text-gray-400 mb-4">{project.description}</p>
                  <motion.button
                    className={`flex items-center ${
                      project.status === 'coming-soon'
                        ? 'text-gray-500 cursor-not-allowed'
                        : 'text-pink-500 hover:text-pink-400'
                    }`}
                    whileHover={project.status !== 'coming-soon' ? { x: 5 } : {}}
                    disabled={project.status === 'coming-soon'}
                  >
                    View Project
                    <svg
                      className="w-4 h-4 ml-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  </motion.button>
                </div>
              </div>
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-pink-500/20 to-violet-500/20 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                initial={false}
                whileHover={{ scale: 1.02 }}
              />
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Section */}
        <motion.div
          className="py-20 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <div className="bg-gradient-to-r from-pink-500/20 to-violet-500/20 rounded-2xl p-12 relative overflow-hidden">
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-pink-500/20 to-violet-500/20"
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 0.8, 0.5]
              }}
              transition={{ duration: 8, repeat: Infinity }}
            />
            <div className="relative z-10">
              <h2 className="text-3xl font-bold mb-4">Have a Project in Mind?</h2>
              <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                Let's work together to create something amazing. Our team is ready to help bring your vision to life.
              </p>
              <button className="bg-gradient-to-r from-pink-500 to-violet-500 px-8 py-3 rounded-full font-semibold hover:scale-105 transition-transform">
                Start a Project
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default PortfolioPage;