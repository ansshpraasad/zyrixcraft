import React from 'react';
import { motion } from 'framer-motion';

const ServicesScreen = () => {
  const services = [
    {
      title: 'Web Development',
      description: 'Custom websites and web applications built with modern technologies.',
      icon: '💻',
      features: [
        'Responsive Design',
        'SEO Optimization',
        'Performance Tuning',
        'API Integration'
      ]
    },
    {
      title: 'Mobile Apps',
      description: 'Native and cross-platform mobile applications.',
      icon: '📱',
      features: [
        'iOS & Android',
        'React Native',
        'Push Notifications',
        'Offline Support'
      ]
    },
    {
      title: 'UI/UX Design',
      description: 'Beautiful and intuitive interfaces that users love.',
      icon: '🎨',
      features: [
        'User Research',
        'Wireframing',
        'Prototyping',
        'User Testing'
      ]
    },
    {
      title: 'E-commerce',
      description: 'Online stores and shopping experiences.',
      icon: '🛍️',
      features: [
        'Payment Integration',
        'Inventory Management',
        'Order Processing',
        'Analytics'
      ]
    },
    {
      title: 'Cloud Solutions',
      description: 'Scalable cloud infrastructure and hosting.',
      icon: '☁️',
      features: [
        'AWS/Azure/GCP',
        'Auto-scaling',
        'Backup & Recovery',
        'Security'
      ]
    },
    {
      title: 'Consulting',
      description: 'Expert advice and technical guidance.',
      icon: '📊',
      features: [
        'Technical Review',
        'Architecture Design',
        'Best Practices',
        'Team Training'
      ]
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-blue-50 pt-24">
      <div className="container mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-6 gradient-text">
            Our Services
          </h1>
          <p className="text-text-secondary max-w-2xl mx-auto">
            We offer a comprehensive range of digital solutions to help your business grow and succeed in the modern digital landscape.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {services.map((service, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="glass-effect rounded-xl p-8 hover-lift"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-2xl font-bold mb-4 gradient-text">
                {service.title}
              </h3>
              <p className="text-text-secondary mb-6">
                {service.description}
              </p>
              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li
                    key={featureIndex}
                    className="flex items-center text-text-secondary"
                  >
                    <svg
                      className="w-5 h-5 mr-2 text-accent-primary"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center mt-16"
        >
          <h2 className="text-2xl font-bold mb-4 gradient-text">
            Ready to Start Your Project?
          </h2>
          <p className="text-text-secondary mb-8">
            Contact us today to discuss how we can help bring your vision to life.
          </p>
          <a
            href="/contact"
            className="inline-flex items-center px-8 py-3 rounded-full gradient-bg text-lg font-semibold hover-lift"
          >
            Get in Touch
            <svg
              className="w-5 h-5 ml-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </a>
        </motion.div>
      </div>
    </div>
  );
};

export default ServicesScreen;
