import React from 'react';

const TimelineScreen = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold">Timeline</h1>
      <ul className="mt-4">
        <li>Q1 2023: Launch of Webcreft</li>
        <li>Q2 2023: First Client Project</li>
        <li>Q3 2023: Expand Service Offerings</li>
        <li>Q4 2023: Launch Portfolio</li>
      </ul>
    </div>
  );
};

export default TimelineScreen;
