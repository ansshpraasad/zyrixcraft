import React from 'react';
import { motion } from 'framer-motion';

const ServicesPage = () => {
  const services = [
    {
      title: 'Web Development',
      description: 'Custom web applications built with modern technologies',
      icon: '💻'
    },
    {
      title: 'Mobile Apps',
      description: 'Native and cross-platform mobile applications',
      icon: '📱'
    },
    {
      title: 'UI/UX Design',
      description: 'Beautiful and intuitive user interfaces',
      icon: '🎨'
    },
    {
      title: 'E-commerce',
      description: 'Online stores and shopping experiences',
      icon: '🛍️'
    },
    {
      title: 'Cloud Solutions',
      description: 'Scalable cloud infrastructure and hosting',
      icon: '☁️'
    },
    {
      title: 'Consulting',
      description: 'Technical consulting and architecture design',
      icon: '📊'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white pt-24">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Services</h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            We offer a comprehensive range of digital services to help your business thrive
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-lg p-6 rounded-xl hover:bg-white/10 transition-all"
            >
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-xl font-bold mb-2">{service.title}</h3>
              <p className="text-gray-400">{service.description}</p>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center py-20 bg-white/5 backdrop-blur-lg rounded-xl"
        >
          <h2 className="text-3xl font-bold mb-4">Ready to Start Your Project?</h2>
          <p className="text-gray-300 mb-8 max-w-xl mx-auto">
            Let's discuss how we can help you achieve your digital goals
          </p>
          <button className="bg-gradient-to-r from-pink-500 to-violet-500 px-8 py-3 rounded-full font-semibold transition-all hover:scale-105">
            Contact Us
          </button>
        </motion.div>
      </div>
    </div>
  );
};

export default ServicesPage;