import React, { useState } from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  CodeBracketIcon, RocketLaunchIcon, PaintBrushIcon, Bars3Icon, XMarkIcon,
  DevicePhoneMobileIcon, GlobeAltIcon, CubeIcon, ChartBarIcon,
  EnvelopeIcon, PhoneIcon, MapPinIcon, UserGroupIcon, LightBulbIcon,
  CheckCircleIcon, QuestionMarkCircleIcon, CommandLineIcon,
  NewspaperIcon, ClockIcon, TrophyIcon, UsersIcon, CloudIcon, BeakerIcon, HeartIcon
} from '@heroicons/react/24/outline';

// Import screens
import HomeScreen from './screens/HomeScreen';
import ServicesScreen from './screens/ServicesScreen';
import PortfolioScreen from './screens/PortfolioScreen';
import AboutScreen from './screens/AboutScreen';
import BlogScreen from './screens/BlogScreen';
import ContactScreen from './screens/ContactScreen';

const NavigationHeader = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Portfolio', path: '/portfolio' },
    { name: 'About', path: '/about' },
    { name: 'Blog', path: '/blog' },
    { name: 'Contact', path: '/contact' }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-effect">
      <nav className="container mx-auto px-4 sm:px-6 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold gradient-text">
            Zyrixcraft
          </Link>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 focus:outline-none"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? (
              <XMarkIcon className="w-6 h-6" />
            ) : (
              <Bars3Icon className="w-6 h-6" />
            )}
          </button>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className="nav-link"
              >
                {item.name}
              </Link>
            ))}
          </div>

          {/* Mobile Navigation */}
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{
              opacity: isMenuOpen ? 1 : 0,
              x: isMenuOpen ? 0 : '100%'
            }}
            transition={{ duration: 0.3 }}
            className={`fixed top-0 right-0 h-screen w-full sm:w-80 bg-white shadow-lg z-50 md:hidden ${
              isMenuOpen ? 'block' : 'hidden'
            }`}
          >
            <div className="p-6">
              <div className="flex justify-between items-center mb-8">
                <Link 
                  to="/" 
                  className="text-2xl font-bold gradient-text"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Zyrixcraft
                </Link>
                <button
                  onClick={toggleMenu}
                  className="p-2 rounded-lg hover:bg-gray-100 focus:outline-none"
                  aria-label="Close menu"
                >
                  <XMarkIcon className="w-6 h-6" />
                </button>
              </div>
              <div className="flex flex-col space-y-4">
                {navItems.map((item) => (
                  <Link
                    key={item.name}
                    to={item.path}
                    className="nav-link block py-3 text-lg"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </nav>
    </header>
  );
};

const features = [
  {
    title: 'Custom Web Development',
    description: 'Tailored solutions built with cutting-edge technologies',
    icon: CodeBracketIcon,
  },
  {
    title: 'Modern UI/UX Design',
    description: 'Beautiful, intuitive interfaces that engage users',
    icon: PaintBrushIcon,
  },
  {
    title: 'Digital Innovation',
    description: 'Transform your ideas into powerful digital solutions',
    icon: RocketLaunchIcon,
  },
];

const services = [
  {
    icon: GlobeAltIcon,
    title: 'Web Applications',
    description: 'Full-stack web applications with modern frameworks and cloud infrastructure.',
  },
  {
    icon: DevicePhoneMobileIcon,
    title: 'Mobile Development',
    description: 'Native and cross-platform mobile apps for iOS and Android.',
  },
  {
    icon: CubeIcon,
    title: '3D & Interactive',
    description: 'Immersive 3D experiences and interactive web elements.',
  },
  {
    icon: ChartBarIcon,
    title: 'Analytics & SEO',
    description: 'Data-driven optimization and search engine visibility.',
  },
];

const portfolio = [
  {
    title: 'E-Commerce Platform',
    category: 'Web Development',
    image: 'https://placehold.co/600x400/indigo/white/png?text=E-Commerce',
  },
  {
    title: 'Fitness App',
    category: 'Mobile App',
    image: 'https://placehold.co/600x400/purple/white/png?text=Fitness+App',
  },
  {
    title: '3D Product Configurator',
    category: 'Interactive',
    image: 'https://placehold.co/600x400/pink/white/png?text=3D+Config',
  },
];

const testimonials = [
  {
    name: 'Sarah Johnson',
    role: 'CEO, TechStart',
    content: 'Zyrixcraft transformed our digital presence completely. Their attention to detail and innovative solutions exceeded our expectations.',
    image: 'https://placehold.co/100/purple/white/png?text=SJ',
  },
  {
    name: 'Michael Chen',
    role: 'Founder, InnovateCo',
    content: 'The team\'s expertise in both design and development helped us launch our product months ahead of schedule.',
    image: 'https://placehold.co/100/indigo/white/png?text=MC',
  },
];

const techStack = [
  {
    category: 'Frontend',
    technologies: [
      { name: 'React', icon: <CodeBracketIcon className="w-6 h-6" /> },
      { name: 'Next.js', icon: <RocketLaunchIcon className="w-6 h-6" /> },
      { name: 'TypeScript', icon: <CodeBracketIcon className="w-6 h-6" /> }
    ]
  },
  {
    category: 'Backend',
    technologies: [
      { name: 'Node.js', icon: <CommandLineIcon className="w-6 h-6" /> },
      { name: 'Python', icon: <CodeBracketIcon className="w-6 h-6" /> },
      { name: 'Java', icon: <CubeIcon className="w-6 h-6" /> }
    ]
  },
  {
    category: 'Database',
    technologies: [
      { name: 'PostgreSQL', icon: <CubeIcon className="w-6 h-6" /> },
      { name: 'MongoDB', icon: <CubeIcon className="w-6 h-6" /> }
    ]
  },
  {
    category: 'Mobile',
    technologies: [
      { name: 'React Native', icon: <DevicePhoneMobileIcon className="w-6 h-6" /> },
      { name: 'Flutter', icon: <DevicePhoneMobileIcon className="w-6 h-6" /> },
      { name: 'iOS', icon: <DevicePhoneMobileIcon className="w-6 h-6" /> },
      { name: 'Android', icon: <DevicePhoneMobileIcon className="w-6 h-6" /> }
    ]
  }
];

const processSteps = [
  {
    title: 'Discovery',
    description: 'We dive deep into your requirements, understanding your business goals and target audience.',
    icon: <LightBulbIcon className="w-12 h-12" />,
    color: 'bg-blue-50 text-blue-600',
    gradient: 'from-blue-500/20 to-blue-600/20',
    benefits: [
      'In-depth business analysis',
      'Market research & competitor analysis',
      'User persona development',
      'Project scope definition',
      'Technical requirements gathering',
      'Budget and timeline planning'
    ]
  },
  {
    title: 'Planning',
    description: 'Creating detailed project roadmap, wireframes, and technical specifications.',
    icon: <ClockIcon className="w-12 h-12" />,
    color: 'bg-purple-50 text-purple-600',
    gradient: 'from-purple-500/20 to-purple-600/20',
    benefits: [
      'Detailed project timeline',
      'Resource allocation strategy',
      'Technical architecture design',
      'UI/UX wireframing',
      'Database schema planning',
      'Security implementation strategy'
    ]
  },
  {
    title: 'Development',
    description: 'Agile development process with regular updates and continuous integration.',
    icon: <CodeBracketIcon className="w-12 h-12" />,
    color: 'bg-green-50 text-green-600',
    gradient: 'from-green-500/20 to-green-600/20',
    benefits: [
      'Agile sprint planning',
      'Regular code reviews',
      'Continuous integration/deployment',
      'Quality assurance testing',
      'Performance optimization',
      'Security testing'
    ]
  },
  {
    title: 'Testing',
    description: 'Comprehensive testing to ensure quality, performance, and security.',
    icon: <BeakerIcon className="w-12 h-12" />,
    color: 'bg-yellow-50 text-yellow-600',
    gradient: 'from-yellow-500/20 to-yellow-600/20',
    benefits: [
      'Unit testing',
      'Integration testing',
      'User acceptance testing',
      'Performance testing',
      'Security vulnerability scanning',
      'Cross-browser compatibility'
    ]
  },
  {
    title: 'Deployment',
    description: 'Smooth deployment process with minimal downtime and maximum reliability.',
    icon: <RocketLaunchIcon className="w-12 h-12" />,
    color: 'bg-pink-50 text-pink-600',
    gradient: 'from-pink-500/20 to-pink-600/20',
    benefits: [
      'Production environment setup',
      'Zero-downtime deployment',
      'Automated backup systems',
      'Performance monitoring',
      'Error tracking setup',
      'Documentation delivery'
    ]
  },
  {
    title: 'Support',
    description: 'Ongoing maintenance and support to ensure your project continues to thrive.',
    icon: <HeartIcon className="w-12 h-12" />,
    color: 'bg-red-50 text-red-600',
    gradient: 'from-red-500/20 to-red-600/20',
    benefits: [
      '24/7 technical support',
      'Regular maintenance updates',
      'Performance optimization',
      'Security patches',
      'Feature enhancements',
      'Analytics and reporting'
    ]
  }
];

const workflowSteps = [
  {
    title: 'Discovery',
    description: 'We dive deep into your requirements, understanding your business goals and target audience.',
    icon: LightBulbIcon,
  },
  {
    title: 'Planning',
    description: 'Creating detailed project roadmap, wireframes, and technical specifications.',
    icon: ClockIcon,
  },
  {
    title: 'Development',
    description: 'Agile development process with regular updates and continuous integration.',
    icon: CodeBracketIcon,
  },
];

const teamServices = [
  {
    id: 1,
    service: 'Web Development',
    icon: <CodeBracketIcon className="w-12 h-12" />,
    skills: [
      'Full-Stack Development',
      'Frontend Frameworks',
      'Backend Systems',
      'API Development',
      'Database Design',
      'Cloud Integration'
    ],
    gradient: 'from-blue-600/90 to-indigo-600/90'
  },
  {
    id: 2,
    service: 'UI/UX Design',
    icon: <PaintBrushIcon className="w-12 h-12" />,
    skills: [
      'User Interface Design',
      'User Experience Design',
      'Wireframing',
      'Prototyping',
      'Design Systems',
      'Responsive Design'
    ],
    gradient: 'from-purple-600/90 to-pink-600/90'
  },
  {
    id: 3,
    service: 'Mobile Development',
    icon: <DevicePhoneMobileIcon className="w-12 h-12" />,
    skills: [
      'iOS Development',
      'Android Development',
      'Cross-platform Apps',
      'Mobile UI Design',
      'App Performance',
      'Mobile Security'
    ],
    gradient: 'from-pink-600/90 to-rose-600/90'
  },
  {
    id: 4,
    service: 'DevOps & Cloud',
    icon: <CloudIcon className="w-12 h-12" />,
    skills: [
      'CI/CD Pipelines',
      'Cloud Architecture',
      'Server Management',
      'Monitoring & Logging',
      'Security Practices',
      'Scalability'
    ],
    gradient: 'from-violet-600/90 to-purple-600/90'
  }
];

const pricingPlans = [
  {
    name: 'Startup',
    price: '$2,999',
    description: 'Perfect for small businesses',
    features: [
      'Custom Website Design',
      'Mobile Responsive',
      '5 Pages',
      'Basic SEO',
      'Contact Form',
      '2 Revisions'
    ]
  },
  {
    name: 'Business',
    price: '$5,999',
    description: 'Ideal for growing companies',
    features: [
      'Advanced Website Design',
      'E-commerce Integration',
      '10 Pages',
      'Advanced SEO',
      'CMS Integration',
      'Unlimited Revisions'
    ]
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    description: 'For large organizations',
    features: [
      'Custom Web Application',
      'Full-stack Development',
      'Unlimited Pages',
      'Enterprise SEO',
      'Custom Integrations',
      'Dedicated Support'
    ]
  }
];

const faqItems = [
  {
    question: 'How long does it take to complete a project?',
    answer: 'Project timelines vary based on complexity. A typical website takes 4-8 weeks, while complex web applications may take 3-6 months.'
  },
  {
    question: 'Do you provide ongoing support?',
    answer: 'Yes, we offer various maintenance and support packages to keep your application running smoothly after launch.'
  },
  {
    question: 'What is your development process?',
    answer: 'We follow an agile methodology with regular sprints, continuous communication, and iterative development to ensure quality.'
  },
  {
    question: 'Can you help with existing projects?',
    answer: 'Absolutely! We can audit, improve, or take over maintenance of existing web applications.'
  }
];

const blogPosts = [
  {
    id: 1,
    title: "Professional Web Development Guide 2025",
    excerpt: "A comprehensive professional guide to modern web development. Master essential technologies, industry best practices, and professional workflows.",
    image: "https://placehold.co/800x400/gradient-1/white/png?text=Professional+Web+Dev",
    author: {
      name: "Ansh Prasad",
      role: "Professional Web Developer",
      avatar: "https://placehold.co/100/purple/white/png?text=AP"
    },
    date: "Jan 22, 2025",
    readTime: "5 min read",
    tags: ["Professional", "Web Development"]
  },
  {
    id: 2,
    title: "My Journey: From Learning to Building",
    excerpt: "Personal insights and lessons learned during my journey into web development. Tips and resources for fellow beginners.",
    image: "https://placehold.co/800x400/gradient-2/white/png?text=Dev+Journey",
    author: {
      name: "Abdul Raja",
      role: "Web Developer",
      avatar: "https://placehold.co/100/indigo/white/png?text=AR"
    },
    date: "Jan 20, 2025",
    readTime: "4 min read",
    tags: ["Personal", "Learning"]
  },
  {
    id: 3,
    title: "Essential Developer Tools for Beginners",
    excerpt: "A curated list of must-have tools and resources that every beginner developer should know about.",
    image: "https://placehold.co/800x400/gradient-3/white/png?text=Dev+Tools",
    author: {
      name: "Adarsh Jaiswal",
      role: "Web Developer",
      avatar: "https://placehold.co/100/pink/white/png?text=AJ"
    },
    date: "Jan 18, 2025",
    readTime: "6 min read",
    tags: ["Tools", "Resources"]
  },
  {
    id: 4,
    title: "Modern Frontend Development Practices",
    excerpt: "Exploring the latest trends and best practices in frontend development. From responsive design to performance optimization.",
    image: "https://placehold.co/800x400/gradient-4/white/png?text=Frontend+Dev",
    author: {
      name: "Sachin Mathur",
      role: "Web Developer",
      avatar: "https://placehold.co/100/cyan/white/png?text=SM"
    },
    date: "Jan 16, 2025",
    readTime: "7 min read",
    tags: ["Frontend", "Best Practices"]
  }
];

const projectTimeline = [
  {
    year: '2024',
    projects: [
      {
        title: 'E-commerce Platform Redesign',
        client: 'Fashion Retail Co.',
        description: 'Complete overhaul of online shopping experience',
      },
      {
        title: 'Mobile Banking App',
        client: 'Digital Bank Ltd.',
        description: 'Secure and intuitive banking application',
      },
    ],
  },
  {
    year: '2023',
    projects: [
      {
        title: 'Healthcare Management System',
        client: 'Medical Center Inc.',
        description: 'Integrated patient care platform',
      },
      {
        title: 'Educational Platform',
        client: 'Online Learning Corp',
        description: 'Interactive learning management system',
      },
    ],
  },
];

const stats = [
  {
    label: 'Innovative Solutions',
    value: 'Modern',
    icon: <RocketLaunchIcon className="w-12 h-12" />
  },
  {
    label: 'Quality First',
    value: 'Best',
    icon: <CheckCircleIcon className="w-12 h-12" />
  },
  {
    label: 'Customer Focus',
    value: 'Always',
    icon: <HeartIcon className="w-12 h-12" />
  }
];

const App = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-blue-50 text-text-primary">
      <NavigationHeader />
      <Routes>
        <Route path="/" element={<HomeScreen />} />
        <Route path="/services" element={<ServicesScreen />} />
        <Route path="/portfolio" element={<PortfolioScreen />} />
        <Route path="/about" element={<AboutScreen />} />
        <Route path="/blog" element={<BlogScreen />} />
        <Route path="/contact" element={<ContactScreen />} />
      </Routes>

      {/* Global Footer */}
      <motion.footer 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="text-center py-6 bg-gradient-to-r from-blue-900/10 to-purple-900/10 backdrop-blur-sm border-t border-gray-800"
      >
        <p className="text-gray-400"> 2025 Zyrixcraft. All rights reserved.</p>
      </motion.footer>
    </div>
  );
};

export default App;
