import React from 'react';
import { motion } from 'framer-motion';

export default function StatisticsScreen() {
  return (
    <section className="container mx-auto px-6 py-20">
      <div className="text-center">
        <h2 className="text-4xl font-bold mb-4">Our Journey Begins</h2>
        <p className="text-gray-300">We are just starting our journey. Stay tuned for updates!</p>
      </div>
    </section>
  );
}
