import React from 'react';
import { motion } from 'framer-motion';

const HomePage = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white pt-24">
      {/* Hero Section */}
      <section className="relative min-h-[calc(100vh-6rem)] flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center px-6"
        >
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Welcome to
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-violet-500"> Zyrixcraft</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Crafting exceptional digital experiences with innovative web solutions.
            We turn your vision into reality with cutting-edge technology.
          </p>
          <div className="flex gap-4 justify-center">
            <button className="bg-gradient-to-r from-pink-500 to-violet-500 px-8 py-3 rounded-full font-semibold transition-all hover:scale-105">
              Start Your Project
            </button>
            <button className="border-2 border-white px-8 py-3 rounded-full font-semibold transition-all hover:bg-white hover:text-purple-900">
              Our Work
            </button>
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold mb-4">Why Choose Us</h2>
            <p className="text-gray-300 max-w-2xl mx-auto">
              We combine creativity with technical expertise to deliver outstanding results
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: 'Modern Design',
                description: 'Clean and modern designs that make your brand stand out',
                icon: '🎨'
              },
              {
                title: 'Performance First',
                description: 'Optimized for speed and exceptional user experience',
                icon: '⚡'
              },
              {
                title: 'Mobile Responsive',
                description: 'Perfectly adapted for all devices and screen sizes',
                icon: '📱'
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white/5 backdrop-blur-lg p-6 rounded-xl hover:bg-white/10 transition-all"
              >
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-400">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;