import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const BlogScreen = () => {
  const blogPosts = [
    {
      category: 'Web Development',
      title: 'The Future of Web Development in 2025',
      date: 'January 23, 2025',
      author: 'Adarsh Jaiswal',
      content: `The landscape of web development is rapidly evolving, bringing exciting new possibilities for developers and businesses alike. In this comprehensive guide, we'll explore the latest trends and technologies that are shaping the future of web development.

Key Trends:
1. AI-Powered Development
- Automated code generation and optimization
- Intelligent debugging and testing
- Personalized user experiences through AI

2. WebAssembly Revolution
- Near-native performance in web applications
- Enhanced gaming and 3D visualization
- Cross-platform compatibility

3. Progressive Web Apps 2.0
- Advanced offline capabilities
- Improved performance metrics
- Enhanced mobile integration

4. Serverless Architecture
- Reduced infrastructure management
- Improved scalability
- Cost-effective solutions

Impact on Businesses:
- Faster development cycles
- Reduced maintenance costs
- Enhanced user experiences
- Improved performance metrics`,
      readTime: '8 min read'
    },
    {
      category: 'Design',
      title: 'Mastering UI/UX Design Principles',
      date: 'January 22, 2025',
      author: 'Abdul Raja',
      content: `Creating intuitive and engaging user interfaces is crucial for modern web applications. This guide explores essential UI/UX design principles that can transform your digital products.

Key Principles:
1. Visual Hierarchy
- Typography and font scaling
- Color theory and contrast
- Layout composition

2. User-Centered Design
- Persona development
- User journey mapping
- Accessibility considerations

3. Responsive Design
- Mobile-first approach
- Fluid layouts
- Breakpoint optimization

4. Interaction Design
- Micro-interactions
- Animation principles
- Feedback mechanisms

Best Practices:
- Regular user testing
- Iterative design process
- Performance optimization
- Cross-device compatibility`,
      readTime: '6 min read'
    },
    {
      category: 'Innovation',
      title: 'Embracing AI in Modern Web Apps',
      date: 'January 21, 2025',
      author: 'Ansh Prasad',
      content: `Artificial Intelligence is revolutionizing web development, creating smarter and more personalized user experiences. Let's explore how AI is transforming web applications.

Key Applications:
1. Personalization
- User behavior analysis
- Content recommendations
- Dynamic UI adaptation

2. Natural Language Processing
- Chatbots and virtual assistants
- Content generation
- Language translation

3. Computer Vision
- Image recognition
- Visual search
- AR/VR integration

4. Predictive Analytics
- User behavior prediction
- Performance optimization
- Business intelligence

Implementation Strategies:
- API integration
- Model selection
- Data privacy
- Performance considerations`,
      readTime: '7 min read'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-blue-50 pt-24">
      <div className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-6 gradient-text typing-effect">
            Our Blog
          </h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto code-appear">
            Insights, tutorials, and updates from our team of experts.
          </p>
        </motion.div>

        {/* Blog Posts */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid gap-12"
        >
          {blogPosts.map((post, index) => (
            <motion.article
              key={index}
              variants={itemVariants}
              className="glass-effect rounded-xl p-8 hover-glow"
            >
              <div className="mb-4">
                <span className="text-sm text-accent-primary font-medium">
                  {post.category}
                </span>
                <h2 className="text-2xl font-bold mt-2 mb-3 gradient-text highlight-line">
                  {post.title}
                </h2>
                <div className="flex items-center text-text-secondary text-sm mb-6">
                  <span>{post.author}</span>
                  <span className="mx-2">•</span>
                  <span>{post.date}</span>
                  <span className="mx-2">•</span>
                  <span>{post.readTime}</span>
                </div>
              </div>
              
              <div className="prose prose-lg max-w-none text-text-secondary code-block">
                <pre className="whitespace-pre-wrap font-sans">
                  {post.content}
                </pre>
              </div>
              
              <div className="mt-6 flex items-center justify-between">
                <Link
                  to="#"
                  className="text-accent-primary hover:text-accent-secondary transition-colors inline-flex items-center"
                >
                  Read full article
                  <svg
                    className="w-4 h-4 ml-1"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                </Link>
                <div className="flex items-center space-x-4">
                  <button className="text-text-secondary hover:text-accent-primary transition-colors">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  </button>
                  <button className="text-text-secondary hover:text-accent-primary transition-colors">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                    </svg>
                  </button>
                </div>
              </div>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </div>
  );
};

export default BlogScreen;
