# Webcreft - Web Development Agency

A modern landing page for Webcreft, a professional web development agency specializing in custom web solutions and digital experiences.

## Features

- Modern, responsive design
- Stunning animations with Framer Motion
- Interactive UI elements
- Gradient effects and glassmorphism
- Mobile-first approach

## Tech Stack

- React 18
- Vite
- Tailwind CSS
- Framer Motion
- Hero Icons

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm run dev
   ```

3. Build for production:
   ```bash
   npm run build
   ```

4. Preview production build:
   ```bash
   npm run preview
   ```

## Development

The project uses:
- Vite for fast development and building
- Tailwind CSS for modern styling
- Framer Motion for smooth animations
- Hero Icons for beautiful UI elements

## License

Copyright 2025 Webcreft. All rights reserved.
