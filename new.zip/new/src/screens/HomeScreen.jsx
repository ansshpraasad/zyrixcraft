import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  CodeBracketIcon, RocketLaunchIcon, PaintBrushIcon,
  DevicePhoneMobileIcon, GlobeAltIcon, CubeIcon, ChartBarIcon,
  CommandLineIcon, LightBulbIcon, BeakerIcon
} from '@heroicons/react/24/outline';

const HomeScreen = () => {
  const services = [
    {
      title: 'Web Development',
      description: 'Custom web applications built with modern technologies',
      icon: <CodeBracketIcon className="w-8 h-8 sm:w-10 sm:h-10" />,
    },
    {
      title: 'Mobile Apps',
      description: 'Native and cross-platform mobile applications',
      icon: <DevicePhoneMobileIcon className="w-8 h-8 sm:w-10 sm:h-10" />,
    },
    {
      title: 'UI/UX Design',
      description: 'Beautiful and intuitive user interfaces',
      icon: <PaintBrushIcon className="w-8 h-8 sm:w-10 sm:h-10" />,
    }
  ];

  const features = [
    {
      title: 'Modern Technologies',
      description: 'Using the latest frameworks and tools',
      icon: <RocketLaunchIcon className="w-6 h-6 sm:w-8 sm:h-8" />,
    },
    {
      title: 'Global Reach',
      description: 'Serving clients worldwide',
      icon: <GlobeAltIcon className="w-6 h-6 sm:w-8 sm:h-8" />,
    },
    {
      title: 'Scalable Solutions',
      description: 'Built to grow with your business',
      icon: <CubeIcon className="w-6 h-6 sm:w-8 sm:h-8" />,
    },
    {
      title: 'Performance Focus',
      description: 'Optimized for speed and efficiency',
      icon: <ChartBarIcon className="w-6 h-6 sm:w-8 sm:h-8" />,
    },
    {
      title: 'Innovation',
      description: 'Cutting-edge development practices',
      icon: <BeakerIcon className="w-6 h-6 sm:w-8 sm:h-8" />,
    },
    {
      title: 'Technical Excellence',
      description: 'Best-in-class code quality',
      icon: <CommandLineIcon className="w-6 h-6 sm:w-8 sm:h-8" />,
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Banner Section */}
      <div className="relative bg-white dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center py-12 sm:py-16 lg:py-24 gap-8 lg:gap-12">
            {/* Text Content */}
            <motion.div 
              className="flex-1 text-center lg:text-left max-w-2xl lg:max-w-none"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-4 sm:mb-6">
                Web Development Solutions
              </h1>
              <p className="text-base sm:text-lg md:text-xl text-gray-600 dark:text-gray-300 mb-6 sm:mb-8 max-w-xl mx-auto lg:mx-0">
                We create stunning websites and applications that help businesses grow in the digital age.
              </p>
              <div className="flex flex-row gap-4 justify-center lg:justify-start">
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center px-6 py-3 text-sm sm:text-base font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 transition duration-150 ease-in-out shadow-lg hover:shadow-xl"
                >
                  Get Started
                  <RocketLaunchIcon className="ml-2 -mr-1 h-4 w-4 sm:h-5 sm:w-5" />
                </Link>
                <Link
                  to="/portfolio"
                  className="inline-flex items-center justify-center px-6 py-3 text-sm sm:text-base font-medium rounded-lg text-gray-900 dark:text-white border-2 border-gray-300 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 transition duration-150 ease-in-out"
                >
                  View Portfolio
                  <GlobeAltIcon className="ml-2 -mr-1 h-4 w-4 sm:h-5 sm:w-5" />
                </Link>
              </div>
            </motion.div>
            
            {/* Animated Illustration */}
            <motion.div 
              className="flex-1 w-full max-w-md lg:max-w-none mt-8 lg:mt-0"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="relative w-full max-w-lg mx-auto">
                {/* Background blobs - hidden on very small screens */}
                <div className="hidden sm:block">
                  <div className="absolute top-0 -left-4 w-48 sm:w-72 h-48 sm:h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob" />
                  <div className="absolute top-0 -right-4 w-48 sm:w-72 h-48 sm:h-72 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000" />
                  <div className="absolute -bottom-8 left-20 w-48 sm:w-72 h-48 sm:h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000" />
                </div>
                <div className="relative px-4 sm:px-0">
                  <img 
                    src="/images/hero-illustration.svg" 
                    alt="Web Development" 
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="pt-24 sm:pt-32 pb-16 sm:pb-20">
        <div className="container mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 gradient-text typing-effect">
              Web Development Solutions
            </h1>
            <p className="text-lg sm:text-xl text-gray-600 mb-8 code-appear">
              We create stunning websites and applications that help businesses grow in the digital age.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/contact"
                className="w-full sm:w-auto px-8 py-3 rounded-full gradient-bg text-white font-semibold hover-glow"
              >
                Get Started
              </Link>
              <Link
                to="/portfolio"
                className="w-full sm:w-auto px-8 py-3 rounded-full border-2 border-accent-primary text-accent-primary font-semibold hover:bg-accent-primary hover:text-white transition-colors"
              >
                View Portfolio
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 sm:py-20 bg-gradient-to-b from-white to-blue-50">
        <div className="container mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12 sm:mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4 gradient-text">
              Our Services
            </h2>
            <p className="text-lg text-gray-600">
              Comprehensive solutions for your digital needs
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                className="glass-effect rounded-xl p-6 sm:p-8 hover-glow"
              >
                <div className="text-accent-primary mb-4">{service.icon}</div>
                <h3 className="text-xl sm:text-2xl font-bold mb-3 gradient-text">
                  {service.title}
                </h3>
                <p className="text-gray-600">
                  {service.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 sm:py-20">
        <div className="container mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12 sm:mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4 gradient-text">
              Why Choose Us
            </h2>
            <p className="text-lg text-gray-600">
              Experience the difference of working with experts
            </p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="glass-effect rounded-xl p-6 hover-glow"
              >
                <div className="flex items-center mb-4">
                  <div className="text-accent-primary mr-3">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg sm:text-xl font-semibold gradient-text">
                    {feature.title}
                  </h3>
                </div>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-20 bg-gradient-to-b from-white to-blue-50">
        <div className="container mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-6 gradient-text">
              Ready to Start Your Project?
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Let's work together to bring your vision to life. Contact us today for a free consultation.
            </p>
            <Link
              to="/contact"
              className="inline-block px-8 py-3 rounded-full gradient-bg text-white font-semibold hover-glow"
            >
              Get in Touch
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default HomeScreen;
