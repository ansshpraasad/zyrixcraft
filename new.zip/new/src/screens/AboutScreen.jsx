import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const AboutScreen = () => {
  const teamMembers = [
    {
      name: 'Ansh Prasad',
      role: 'Founder',
      description: 'Passionate about creating innovative solutions that make a difference.',
      initial: 'A'
    },
    {
      name: 'Adarsh Jaiswal',
      role: 'Co-Founder',
      description: 'Driving innovation and leading the team towards excellence.',
      initial: 'A'
    },
    {
      name: 'Abdul Raja',
      role: 'Web Developer',
      description: 'Expert in creating beautiful and intuitive user experiences.',
      initial: 'A'
    },
    {
      name: 'Sachin Kumar',
      role: 'Web Developer',
      description: 'Full-stack developer with a love for clean, efficient code.',
      initial: 'S'
    }
  ];

  const blogPosts = [
    {
      category: 'Web Development',
      title: 'The Future of Web Development in 2025',
      description: 'Explore the latest trends and technologies shaping the future of web development, from AI integration to advanced user experiences.',
      link: '/blog/future-web-development-2025'
    },
    {
      category: 'Design',
      title: 'Mastering UI/UX Design Principles',
      description: 'Learn the essential principles of modern UI/UX design that can transform your digital products into user-friendly experiences.',
      link: '/blog/mastering-uiux-design'
    },
    {
      category: 'Innovation',
      title: 'Embracing AI in Modern Web Apps',
      description: 'Discover how artificial intelligence is revolutionizing web applications and creating smarter, more personalized user experiences.',
      link: '/blog/ai-modern-web-apps'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-blue-50 pt-24">
      <div className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-6 gradient-text typing-effect">
            About Us
          </h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto code-appear">
            We are a passionate team of designers and developers dedicated to creating exceptional digital experiences. 
            Our mission is to help businesses thrive in the digital age through innovative solutions and cutting-edge technology.
          </p>
        </motion.div>

        {/* Mission & Vision */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 gap-8 mb-20"
        >
          <motion.div
            variants={itemVariants}
            className="glass-effect rounded-xl p-8 hover-glow code-block"
          >
            <h2 className="text-2xl font-bold mb-4 gradient-text highlight-line">Our Mission</h2>
            <p className="text-text-secondary">
              At Webcreft, our mission is to empower businesses through innovative web solutions. 
              We strive to deliver cutting-edge technology that transforms ideas into powerful digital experiences.
            </p>
          </motion.div>

          <motion.div
            variants={itemVariants}
            className="glass-effect rounded-xl p-8 hover-glow code-block"
          >
            <h2 className="text-2xl font-bold mb-4 gradient-text highlight-line">Our Vision</h2>
            <p className="text-text-secondary">
              We envision a world where every business has access to high-quality web development services. 
              Our goal is to break down technological barriers and create a digital landscape where businesses of all sizes can thrive.
            </p>
          </motion.div>
        </motion.div>

        {/* Team Section */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mb-20"
        >
          <h2 className="text-3xl font-bold text-center mb-12 gradient-text typing-effect">
            Our Team
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="glass-effect rounded-xl p-6 text-center hover-glow hover-code"
              >
                <div className="w-20 h-20 rounded-full gradient-bg flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4 bounce-in">
                  {member.initial}
                </div>
                <h3 className="text-xl font-bold mb-2 gradient-text">{member.name}</h3>
                <div className="text-accent-primary mb-3">{member.role}</div>
                <p className="text-text-secondary">{member.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Blog Section */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold text-center mb-12 gradient-text typing-effect">
            Latest from Our Blog
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <motion.article
                key={index}
                variants={itemVariants}
                className="glass-effect rounded-xl p-6 hover-glow code-block"
              >
                <div className="text-sm text-accent-primary font-medium mb-2">
                  {post.category}
                </div>
                <h3 className="text-xl font-bold mb-3 gradient-text highlight-line">
                  {post.title}
                </h3>
                <p className="text-text-secondary mb-4">
                  {post.description}
                </p>
                <Link
                  to={post.link}
                  className="text-accent-primary hover:text-accent-secondary transition-colors inline-flex items-center"
                >
                  Read More
                  <svg
                    className="w-4 h-4 ml-1"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                </Link>
              </motion.article>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AboutScreen;
