import React from 'react';
import { motion } from 'framer-motion';

const PortfolioScreen = () => {
  const futureProjects = [
    {
      title: 'E-commerce Platform',
      description: 'A next-generation shopping experience with AI-powered recommendations.',
      icon: '🛍️',
      status: 'Coming Soon'
    },
    {
      title: 'Healthcare Portal',
      description: 'Revolutionary healthcare management system with telemedicine integration.',
      icon: '🏥',
      status: 'In Development'
    },
    {
      title: 'Learning Management',
      description: 'Advanced e-learning platform with interactive content and real-time collaboration.',
      icon: '📚',
      status: 'Planning'
    },
    {
      title: 'Smart City Dashboard',
      description: 'IoT-powered city monitoring and management system.',
      icon: '🌆',
      status: 'Coming Soon'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  const pulseVariants = {
    initial: { scale: 1 },
    animate: {
      scale: [1, 1.05, 1],
      transition: {
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-blue-50 pt-24">
      <div className="container mx-auto px-6 py-12">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-6 gradient-text typing-effect">
            Our Portfolio
          </h1>
          <p className="text-xl text-text-secondary max-w-3xl mx-auto code-appear">
            Our portfolio is coming soon and will showcase our future projects. 
            Stay tuned for updates.
          </p>
        </motion.div>

        {/* Coming Soon Animation */}
        <motion.div
          variants={pulseVariants}
          initial="initial"
          animate="animate"
          className="max-w-2xl mx-auto mb-20"
        >
          <div className="glass-effect rounded-xl p-12 text-center matrix-bg">
            <div className="text-6xl mb-6">🚀</div>
            <h2 className="text-3xl font-bold mb-4 gradient-text">
              Portfolio Launch
            </h2>
            <div className="terminal mb-6">
              <span className="terminal-text loading-dots">
                Initializing awesome projects
              </span>
            </div>
            <div className="flex justify-center space-x-2">
              <span className="inline-flex h-3 w-3 animate-bounce bg-accent-primary rounded-full delay-75"></span>
              <span className="inline-flex h-3 w-3 animate-bounce bg-accent-primary rounded-full delay-100"></span>
              <span className="inline-flex h-3 w-3 animate-bounce bg-accent-primary rounded-full delay-150"></span>
            </div>
          </div>
        </motion.div>

        {/* Future Projects */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-bold text-center mb-12 gradient-text typing-effect">
            Future Projects
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            {futureProjects.map((project, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                className="glass-effect rounded-xl p-8 hover-glow hover-code code-block"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="text-4xl bounce-in">{project.icon}</div>
                  <span className="px-4 py-1 rounded-full text-sm font-medium gradient-bg text-white">
                    {project.status}
                  </span>
                </div>
                <h3 className="text-xl font-bold mb-3 gradient-text highlight-line">
                  {project.title}
                </h3>
                <p className="text-text-secondary">
                  {project.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Newsletter Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center mt-20"
        >
          <h2 className="text-2xl font-bold mb-4 gradient-text">
            Stay Updated
          </h2>
          <p className="text-text-secondary mb-8">
            Subscribe to our newsletter to be the first to know when we launch new projects.
          </p>
          <form className="max-w-md mx-auto flex gap-4">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-2 rounded-full border border-gray-200 focus:outline-none focus:border-accent-primary"
            />
            <button
              type="submit"
              className="px-6 py-2 rounded-full gradient-bg text-white font-semibold hover-glow"
            >
              Notify Me
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default PortfolioScreen;
