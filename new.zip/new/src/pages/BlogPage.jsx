import React from 'react';
import { motion } from 'framer-motion';

const BlogPage = () => {
  const posts = [
    {
      title: 'My Journey: From Learning to Building',
      author: 'Abdul Raja',
      authorInitials: 'AR',
      role: 'Web Developer',
      date: 'Jan 20, 2025',
      readTime: '4 min read',
      excerpt: 'Personal insights and lessons learned during my journey into web development. Tips and resources for fellow beginners.',
      tags: ['Web Development', 'Learning', 'Career']
    },
    {
      title: 'Essential Developer Tools for Beginners',
      author: 'Adarsh Jaiswal',
      authorInitials: 'AJ',
      role: 'Web Developer',
      date: 'Jan 18, 2025',
      readTime: '6 min read',
      excerpt: 'A curated list of must-have tools and resources that every beginner developer should know about.',
      tags: ['Tools', 'Resources', 'Development']
    },
    {
      title: 'Building Scalable Web Applications',
      author: 'Ansh Prasad',
      authorInitials: 'AP',
      role: 'Web Developer',
      date: 'Jan 15, 2025',
      readTime: '8 min read',
      excerpt: 'Learn the best practices for building web applications that can scale with your user base.',
      tags: ['Architecture', 'Scalability', 'Best Practices']
    },
    {
      title: 'Modern Frontend Development Trends',
      author: 'Sachin Mathur',
      authorInitials: 'SM',
      role: 'Web Developer',
      date: 'Jan 12, 2025',
      readTime: '5 min read',
      excerpt: 'Exploring the latest trends and technologies in frontend development for 2025.',
      tags: ['Frontend', 'Trends', 'Technology']
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-black text-white pt-24">
      <div className="container mx-auto px-6">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Blog</h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Insights and experiences from our web developers
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-20">
          {posts.map((post, index) => (
            <motion.article
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-lg rounded-xl p-6 hover:bg-white/10 transition-all"
            >
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-pink-500 to-violet-500 flex items-center justify-center text-white font-semibold">
                  {post.authorInitials}
                </div>
                <div>
                  <h3 className="font-semibold">{post.author}</h3>
                  <div className="text-sm text-gray-400">
                    {post.role} • {post.date} • {post.readTime}
                  </div>
                </div>
              </div>
              <h2 className="text-2xl font-bold mb-3">{post.title}</h2>
              <p className="text-gray-300 mb-4">{post.excerpt}</p>
              <div className="flex flex-wrap gap-2 mb-4">
                {post.tags.map((tag, tagIndex) => (
                  <span
                    key={tagIndex}
                    className="text-sm px-3 py-1 rounded-full bg-white/10 text-gray-300"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <button className="text-pink-500 hover:text-pink-400 font-semibold flex items-center">
                Read More <span className="ml-2">→</span>
              </button>
            </motion.article>
          ))}
        </div>

        {/* Newsletter Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center py-20 bg-white/5 backdrop-blur-lg rounded-xl mb-20"
        >
          <h2 className="text-3xl font-bold mb-4">Subscribe to Our Newsletter</h2>
          <p className="text-gray-300 mb-8 max-w-xl mx-auto">
            Get the latest articles and insights from our web developers delivered straight to your inbox
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center max-w-md mx-auto px-6">
            <input
              type="email"
              placeholder="Enter your email"
              className="bg-white/10 rounded-full px-6 py-3 focus:outline-none focus:ring-2 focus:ring-pink-500 flex-grow"
            />
            <button className="bg-gradient-to-r from-pink-500 to-violet-500 px-8 py-3 rounded-full font-semibold transition-all hover:scale-105">
              Subscribe
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default BlogPage;
