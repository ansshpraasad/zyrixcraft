/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  safelist: [
    {
      pattern: /(bg|text|border|from)-(blue|purple|pink|green|gray|violet|indigo|yellow|red)-(50|100|200|300|400|500|600|700|800|900)/,
      variants: ['hover', 'focus', 'group-hover']
    },
    {
      pattern: /(from|via|to)-(current|transparent|black|white)/,
      variants: ['hover', 'focus']
    },
    'backdrop-blur-sm',
    'backdrop-blur-lg',
    'bg-white/5',
    'bg-white/10',
    'bg-white/20',
    'bg-white/80',
    'bg-black/20',
    'bg-black/80',
    'border-white/10',
    'border-white/20'
  ],
  theme: {
    extend: {
      animation: {
        blob: "blob 7s infinite",
        blink: 'blink 1s step-end infinite'
      },
      keyframes: {
        blob: {
          "0%": {
            transform: "translate(0px, 0px) scale(1)"
          },
          "33%": {
            transform: "translate(30px, -50px) scale(1.1)"
          },
          "66%": {
            transform: "translate(-20px, 20px) scale(0.9)"
          },
          "100%": {
            transform: "translate(0px, 0px) scale(1)"
          }
        },
        blink: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0' }
        }
      },
      colors: {
        'accent-primary': '#3B82F6',   // blue-500
        'accent-secondary': '#8B5CF6',  // violet-500
        text: {
          secondary: '#64748b', // Using a slate-500 color as default for text-secondary
        },
      },
    },
  },
  plugins: [
    require('@tailwindcss/typography'),
  ],
}
